execute at @s run particle minecraft:explosion ~ ~ ~ 0 0 0 0 1 force
execute at @s run playsound minecraft:entity.firework_rocket.blast master @a ~ ~ ~ 2 0.7
execute as @e[distance=..2.5,type=!minecraft:item,type=!minecraft:item_display,type=!minecraft:firework_rocket,sort=nearest,limit=1] at @s run damage @s 20 minecraft:explosion
kill @s