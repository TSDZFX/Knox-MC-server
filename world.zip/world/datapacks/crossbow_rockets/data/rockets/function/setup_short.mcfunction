data modify entity @s LifeTime set value 6
tag @s add rk_short_rocket