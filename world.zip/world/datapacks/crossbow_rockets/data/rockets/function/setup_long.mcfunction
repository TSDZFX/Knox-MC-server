data modify entity @s LifeTime set value 63
tag @s add rk_long_rocket