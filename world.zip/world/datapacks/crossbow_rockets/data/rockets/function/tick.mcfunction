# 1. Tag any new rockets and initialize their score tracking
execute as @e[type=firework_rocket,tag=!rk_seen] at @s run function rockets:setup

# 2. Count down the life of all active rockets every tick
execute as @e[type=firework_rocket,tag=rk_seen] run scoreboard players remove @s rk_life 1

# 3. Trigger short rockets when timer hits 0 or below
execute as @e[type=firework_rocket,tag=rk_short_rocket,scores={rk_life=..0}] at @s run function rockets:boom_short

# 4. Trigger long rockets when timer hits 0 or below
execute as @e[type=firework_rocket,tag=rk_long_rocket,scores={rk_life=..0}] at @s run function rockets:boom_long