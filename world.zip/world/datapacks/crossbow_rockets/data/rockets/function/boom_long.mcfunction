execute at @s run particle minecraft:explosion_emitter ~ ~ ~ 0 0 0 0 1 force
execute at @s run playsound minecraft:entity.generic.explode master @a ~ ~ ~ 4 1
execute as @e[distance=..8,type=!minecraft:item,type=!minecraft:item_display,type=!minecraft:firework_rocket,type=!minecraft:marker] at @s run damage @s 6 minecraft:explosion
kill @s