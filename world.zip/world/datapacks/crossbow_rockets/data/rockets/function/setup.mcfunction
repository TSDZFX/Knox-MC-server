tag @s add rk_seen
execute if data entity @s FireworksItem.components."minecraft:custom_data"{rocket:"short"} run function rockets:setup_short
execute if data entity @s FireworksItem.components."minecraft:custom_data"{rocket:"long"} run function rockets:setup_long
