GIVE COMMANDS
/give @s firework_rocket[custom_data={rocket:"short"},item_name="Breacher Rocket"] 16
/give @s firework_rocket[custom_data={rocket:"long"},item_name="Artillery Rocket"] 16

TUNING
Range:   LifeTime in setup_short / setup_long (blocks = ticks x 1.6)
Damage:  number after "damage @s" in boom_short / boom_long (2 = 1 heart)
Radius:  distance=.. in boom_short / boom_long
